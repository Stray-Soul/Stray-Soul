﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy_Controller : MonoBehaviour
{
    //defines destination
    [SerializeField]
    Transform Destination;
    //gets player object from unity
    public GameObject player;
    //defines a variable 
    NavMeshAgent _NavMeshAgent;


    // Start is called before the first frame update
    void Start()
    {
        //Gets the navmesh agent component
        _NavMeshAgent = this.GetComponent<NavMeshAgent>();

        

    }

    private void SetDestination()
    {
        if (Destination != null)
        {
             Vector3 targetVector = Destination.transform.position;
            _NavMeshAgent.SetDestination(targetVector);

        }

    }


    // Update is called once per frame
    void FixedUpdate()
    {
        SetDestination();
    }
 /*
    private void OnCollisionEnter(Collision collision)
    {
        Destroy(player);
    }
 */
}
