﻿using Assets.Scripts.FSM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AI;

namespace Assets.Scripts.Enemy_AI
{
    //An enemy needs the AI nav mesh agent component and a fsm
    [RequireComponent(typeof(NavMeshAgent), typeof(FiniteStateMachine))]

    //Enemy defined as a class so that each of the AI scripts are pased through this.
    public class Enemy : MonoBehaviour
    {
        //defines the nav mesh agent so that the component can be used in the code
        NavMeshAgent  _navMeshAgent;
        //defines the fsm
        FiniteStateMachine _finiteStateMachine;
        //when the game is loaded, this function is called
        public void Awake()
        {
            //calls the nav mesh agent component
            _navMeshAgent = this.GetComponent<NavMeshAgent>();
            //calls the fsm code.
            _finiteStateMachine = GetComponent<FiniteStateMachine>();
        }

        public void Start()
        {
            
        }

        public void Update()
        {
            
        }
    }
}
