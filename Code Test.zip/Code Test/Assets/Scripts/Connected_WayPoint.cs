﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Connected_WayPoint : MonoBehaviour
{
    //defines 
    [SerializeField]
    protected float _connectivityRadius = 50f;

    List<Connected_WayPoint> _connections;


    // Start is called before the first frame update
    void Start()
    {
        GameObject[] allWaypoints = GameObject.FindGameObjectsWithTag("Waypoint");

        _connections = new List<Connected_WayPoint>();

        for (int i = 0; i < allWaypoints.Length; i++)
        {
            Connected_WayPoint nextWaypoint = allWaypoints[i].GetComponent<Connected_WayPoint>();

            if (nextWaypoint != null)
            {
                if (Vector3.Distance(this.transform.position, nextWaypoint.transform.position) <= _connectivityRadius && nextWaypoint!= this)
                {
                    _connections.Add(nextWaypoint);
                }

            }

        }
    }

    //draws a visual gizmo so you can see the connectivity radius in unity
    public void OnDrawGizmos()
    {

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, _connectivityRadius);
            
    }

    public Connected_WayPoint NextWaypoint(Connected_WayPoint previousWaypoint)
    {
        //For debugging, if there are no waypoints
        if (_connections.Count == 0)
        {
            Debug.LogError("Insufficient waypoint count.");
            return null;

        }
        else if (_connections.Count == 1 && _connections.Contains(previousWaypoint))
        {
            Connected_WayPoint nextWayPoint;
            int nextIndex;

            do
            {
                nextIndex = UnityEngine.Random.Range(0, _connections.Count);
                nextWayPoint = _connections[nextIndex];
            }
            while (nextWayPoint == previousWaypoint);
            return nextWayPoint;
            
            
        }

    }


    // Update is called once per frame
    void Update()
    {
        
    }
}
