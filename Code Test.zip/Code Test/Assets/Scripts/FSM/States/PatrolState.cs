﻿using Assets.Scripts.Enemy_AI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;


namespace Assets.Scripts.FSM.States
{
    [CreateAssetMenu(fileName = "PatrolState", menuName = "Unity-FSM/States/Patrol", order = 2)]

   public class PatrolState: Abstract_FSM_State
    {
        Way_Points[] _patrolPoints;
        int _patrolPointIndex;

        public override void UpdateState()
        {
            throw new NotImplementedException();
        }
    }
}
