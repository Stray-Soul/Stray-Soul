﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.FSM.States
{
    [CreateAssetMenu(fileName ="IdleState", menuName = "Unity-FSM/States/Idle", order =1)]
   public class IdleState : Abstract_FSM_State
    {
        public override bool EnterState()
        {
            base.EnterState();
            Debug.Log("Entered Idle State");
            return true;
        }


        public override void UpdateState()
        {
            Debug.Log("Updating Idle State");
        }

        public override bool ExitState()
        {
            base.ExitState();
            Debug.Log("Exited Idle State");
            return true;
        }
    }
}
