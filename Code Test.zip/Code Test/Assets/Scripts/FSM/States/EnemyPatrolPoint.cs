﻿namespace Assets.Scripts.FSM.States
{
    internal class EnemyPatrolPoint
    {
    }
}